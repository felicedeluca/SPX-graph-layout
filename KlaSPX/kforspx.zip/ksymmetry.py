# #!/bin/bash
# for f in svg/*.svg;
# do
# 	svgfullpath=$(pwd)/$f
# 	filename="${svgfullpath##*/}"
# 	filename="${filename%.*}"
# 	outputfile=$(pwd)"/kcsv/"$filename".csv"
# 	echo $outputfile;
# 	java -jar $(pwd)"/kAnalyzer.jar" $svgfullpath > $outputfile
# 	python get_refl_score.py $outputfile "meas.txt" OK
# done
import networkx as nx
import os
import math

from subprocess import Popen, PIPE


import format_for_klapaukh
import dottocsvconverter

import sys
from networkx.drawing.nx_agraph import write_dot
from networkx.drawing.nx_agraph import read_dot as nx_read_dot

def rotate(G, angle):
	angle = math.radians(angle)
	pos_dict = nx.get_node_attributes(G, "pos")
	for currVertex in nx.nodes(G):
		x = float(pos_dict[currVertex].split(",")[0])
		y = float(pos_dict[currVertex].split(",")[1])
		x_rot = x*math.cos(angle) - y*math.sin(angle)
		y_rot = x*math.sin(angle) + y*math.cos(angle)
		pos_dict[currVertex] = str(x_rot) + "," + str(y_rot)
	nx.set_node_attributes(G, pos_dict, "pos")
	return G

def rotate_to_ideal_symmetry(G):
	angle = compute_symmetry(G)[1]
	G = rotate(G, angle)
	angle = compute_symmetry(G)[1]
	return angle


def get_symmetric_score(G):
	score = compute_symmetry(G)
	return score[0]



def get_reflectional_score(filename):

	desired = [
		"Mirror Symmetry",
		# "Translational Symmetry",
		# "Rotational Symmetry",
		"Angle Deviation From Ideal"
	]

	with open(filename, 'r') as f:
		lines = f.readlines()

	labels = lines[0].strip().split(',')
	values = lines[1].strip().split(',')

	out = []

	results = []

	for prop in desired:
		idx = labels.index(prop)
		out.append(float(values[idx]))
	result = ",".join(map(str,out))

	return out

def compute_symmetry(G):
	'''
	Computes the symmetry of the given graph with respect K metric.
	G: the graph in networkx format
	returns: a list of two values:
	 		a score in the range [0, 1] of symmetricness
	        where
	        0 is non symmetric
	        1 is symmetric

			the `Angle Deviation From Ideal' symmetry computed by the metric
	'''

	svgfullpath = "temp.svg"
	metrics_file = "temp.csv"
	graph_file_path = "temp_g.csv"
	layout_file_path = "temp_l.csv"

	#  Remove files if exist
	if os.path.exists(svgfullpath):
	    os.remove(svgfullpath)
	if os.path.exists(metrics_file):
	    os.remove(metrics_file)
	if os.path.exists(graph_file_path):
	    os.remove(graph_file_path)
	if os.path.exists(layout_file_path):
	    os.remove(layout_file_path)


	# Convert graph in the two svg and csv needed files
	dottocsvconverter.convert(G, graph_file_path, layout_file_path)

	#
	# Convert the two csv files in svg for the score computation
	scale = 1


	layout, edges = format_for_klapaukh.load_graph(graph_file_path, layout_file_path)
	layout = format_for_klapaukh.scale_layout(layout, scale)
	svg = format_for_klapaukh.build_svg(layout, edges, scale)
	format_for_klapaukh.write_svg(svgfullpath, svg)

	# invoke the java pachage
	p = Popen(['java', '-jar', 'kAnalyzer.jar', svgfullpath], stdout=PIPE)
	output = p.stdout.read()

	output_str = output.decode('utf-8')

	metrics = open(metrics_file, "w")
	metrics.write(output_str)
	metrics.close()
	score = get_reflectional_score(metrics_file)

	#  Remove the created temp files if existf
	if os.path.exists(svgfullpath):
	    os.remove(svgfullpath)
	if os.path.exists(metrics_file):
	    os.remove(metrics_file)
	if os.path.exists(graph_file_path):
	    os.remove(graph_file_path)
	if os.path.exists(layout_file_path):
	    os.remove(layout_file_path)

	return score



# G = nx_read_dot("/Users/felicedeluca/Desktop/nonsymmetric.dot")
# # for i in range(0, 360):
# 	# G = rotate(G, i)
# score = get_symmetric_score(G)
# # angle = rotate_to_ideal_symmetry(G)
# print(score)
